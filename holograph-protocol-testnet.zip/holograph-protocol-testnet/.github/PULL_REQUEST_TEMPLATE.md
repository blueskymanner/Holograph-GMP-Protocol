## Describe Changes

I made this more better by doing ...

- Change A
- Change B

## Checklist before requesting a review

- [ ] I have performed a self-review of my code
- [ ] Code styles have been enforced
- [ ] All Hardhat tests are passing
