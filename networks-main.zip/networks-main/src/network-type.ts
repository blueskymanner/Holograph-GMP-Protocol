enum NetworkType {
  local = 'local',
  testnet = 'testnet',
  mainnet = 'mainnet',
}

export { NetworkType };
