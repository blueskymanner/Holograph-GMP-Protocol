# hardhat-holograph-contract-builder
Builds smart contracts in preparation for compiling.
