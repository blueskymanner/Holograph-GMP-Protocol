import {Network} from 'hardhat/types';

// used a fallback as some plugin might override network fields, see for example : https://github.com/sc-forks/solidity-coverage/issues/624
export const store: {
  networks: {[name: string]: Network};
} = {
  networks: {},
};
