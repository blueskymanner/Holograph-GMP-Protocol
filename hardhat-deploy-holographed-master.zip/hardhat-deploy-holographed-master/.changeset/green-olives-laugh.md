---
'hardhat-deploy': patch
---

zksync support
