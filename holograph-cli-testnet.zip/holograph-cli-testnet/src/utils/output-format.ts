export const supportedFormats: string[] = ['clean', 'json', 'yaml']
