export enum TokenUriType {
  ipfs = 'ipfs', //    1
  https = 'https', //   2
  arweave = 'arweave', // 3
}

export enum TokenUriTypeIndex {
  unset, //   0
  ipfs, //    1
  https, //   2
  arweave, // 3
}
