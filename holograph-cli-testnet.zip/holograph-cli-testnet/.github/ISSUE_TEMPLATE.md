## Expected Behavior

## Current Behavior

## How to reproduce (for bugs)

1. Step A
2. Step B
3. Step C <--**Breaks here**

## Possible Solution

## Environment:

Version: 2.0.0-beta.X
