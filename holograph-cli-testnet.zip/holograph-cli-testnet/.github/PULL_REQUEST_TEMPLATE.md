## Describe Changes

I made this better by doing ...

- Change A
- Change B

## Checklist before requesting a review

- [ ] I have performed a self-review of my code
- [ ] Code styles have been enforced
- [ ] I have checked eslint
